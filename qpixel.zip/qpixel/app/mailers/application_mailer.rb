class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@codidact.com'
  layout 'mailer'
end
