# Provides helper methods for use by views under <tt>VotesController</tt>.
module VotesHelper
end
