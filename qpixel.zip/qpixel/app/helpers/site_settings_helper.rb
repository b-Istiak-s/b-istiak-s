# Provides helper methods for use by views under <tt>SiteSettingsController</tt>.
module SiteSettingsHelper
end
