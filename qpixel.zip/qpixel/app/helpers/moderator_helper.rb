# Provides helper methods for use by views under <tt>ModeratorController</tt>.
module ModeratorHelper
end
