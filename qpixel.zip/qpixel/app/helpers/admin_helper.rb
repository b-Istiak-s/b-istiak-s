# Provides helper methods for use by views under <tt>AdminController</tt>.
module AdminHelper
end
