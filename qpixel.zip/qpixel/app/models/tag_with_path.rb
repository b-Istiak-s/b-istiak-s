class TagWithPath < Tag
  self.table_name = 'tags_paths'
end
