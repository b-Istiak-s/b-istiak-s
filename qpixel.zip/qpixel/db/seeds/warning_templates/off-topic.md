We've noticed that you've written a number of posts about topics that are beyond the scope of this site.

You can find out about what's on-topic and what's off-topic on $SiteName in the [help center](/help/faq).

This is just a gentle reminder that we expect posts on this site to stay focused on the topic on-hand.
We have a [Network of communities](https://codidact.com/) that you are free to use; you may find one of our other communities more suitable to some of your posts. If you would like to talk about the possibility of creating a site for a subject not currently covered, please write a post on [meta](https://meta.codidact.com/categories/10) with your request.
Additionally, we have a $ChatLink available for more free-form discussion.

While we appreciate your continued contributions within the scope of this site, we do ask that you make sure that the topic of your posts remain in scope.