We've noticed that you've had some recent interactions on this site that have been less than polite.

In keeping with our [Code of Conduct](/policy/code-of-conduct), we expect everyone using this site to remain respectful, presume good intent, and use common sense when communicating with other members of the site.

We understand that a single person is rarely solely to blame when discussions get heated, and that you may feel that you are not at fault. However, please remember that someone else being out of line does not excuse similar behavior on your part. If someone is being disrespectful or rude, please raise a flag on the comment or post and then disengage from the interaction. A moderator will handle your flag and review the situation.

While we appreciate your continued contributions to $SiteName, we do ask that you stay mindful of your fellow users and abide by the Code of Conduct.