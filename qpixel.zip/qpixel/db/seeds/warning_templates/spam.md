We've noticed that in addition to your contributions to $SiteName, you've also been using this account to promote a product, service, or similar.

This is a gentle reminder that using an account for promotional purposes is against the rules of this site.

Please take a moment to review the guidelines for promotional content here on $SiteName, which can be found in the [help center](/policy/spam).

While we appreciate your continued contributions to $SiteName, we do ask that you stay within the boundaries of the rules about promotional content.